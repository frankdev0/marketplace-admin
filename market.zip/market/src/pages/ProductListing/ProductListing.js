import React from "react";

const ProductListing = () => {
  return (
    <>
      <div>ProductListing</div>
    </>
  );
};

export default ProductListing;
